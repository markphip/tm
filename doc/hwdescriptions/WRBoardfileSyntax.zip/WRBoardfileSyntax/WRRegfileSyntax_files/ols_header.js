// JavaScript Document

document.write("<table border=\"0\"  cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">");
document.write("<tr>");
document.write("<td width=\"50%\"><img src=\"http://www.windriver.com/imagesso/3rd-party-resources/spacer.gif\" width=\"45px\" height=\"1px\" border=\"0\" alt=\"\" /></td>");
	
document.write("<td width=\"886\" bgcolor=\"#ffffff\" align=\"center\">");

document.write("<table bgcolor=\"#FFFFFF\" border=\"0\" width=\"880\">");
document.write("<tr>");
document.write("<td><a href=\"http://www.windriver.com\"><img src=\"http://www.windriver.com/imagesso/3rd-party-resources/header2_0.gif\" width=\"214\" height=\"40\" border=\"0\" align=\"left\" alt=\"\"></a></td>");
document.write("<td width=\"50%\"><img src=\"http://www.windriver.com/imagesso/3rd-party-resources/spacer.gif\"  height=\"10px\" border=\"0\" alt=\"\" /></td>");
document.write("<td nowrap>");
		
			
document.write("<a href=\"/portal/server.pt?space=Opener&control=OpenObject&cached=true&parentname=CommunityPage&parentid=0&in_hi_ClassID=512&in_hi_ObjectID=739&in_hi_OpenerMode=2&\" class=\"centerLinkBold\">Device Software Optimization</a>&nbsp;&nbsp;&middot;&nbsp;&nbsp;<a href=\"/portal/server.pt?space=Opener&control=OpenObject&cached=true&parentname=CommunityPage&parentid=0&in_hi_ClassID=512&in_hi_ObjectID=769&in_hi_OpenerMode=2&\" class=\"centerLink\">VxWorks</a>&nbsp;&nbsp;&middot;&nbsp;&nbsp;<a href=\"/portal/server.pt?space=Opener&control=OpenObject&cached=true&parentname=CommunityPage&parentid=8&in_hi_ClassID=512&in_hi_ObjectID=748&in_hi_OpenerMode=2&\" class=\"centerLink\">Linux</a>&nbsp;");
		
document.write("</td>");
			
document.write("</tr>");
document.write("</table>");
document.write("<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\"880\" height=\"218\">");
document.write("<param name=\"movie\" value=\"http://www.windriver.com/imagesso/3rd-party-resources/ols_top_nav.swf\">");
document.write("<param name=\"quality\" value=\"high\">");
document.write("<embed src=\"http://www.windriver.com/imagesso/3rd-party-resources/ols_top_nav.swf\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\"880\" height=\"218\"></embed>");
document.write("</object>");
document.write("<img src=\"http://www.windriver.com/imagesso/3rd-party-resources/spacer.gif\" width=\"886px\" height=\"1px\" border=\"0\" alt=\"\" />");
document.write("</td>");

document.write("<td width=\"50%\">");
document.write("<img src=\"http://www.windriver.com/imagesso/3rd-party-resources/spacer.gif\" width=\"45px\" height=\"1px\" border=\"0\" alt=\"\" />");
document.write("</td>");

document.write("</tr>");

document.write("</table>");